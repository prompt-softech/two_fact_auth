# django-two_facture_auth_code
Assignment  <br />

We used pycharm tool to build this POC

Have you provided your Twilio settings in the settings_private.py file? By doing so, the example app will be able to call and text you to verify your authentication tokens. Otherwise, the tokens will be shown on the screen.


